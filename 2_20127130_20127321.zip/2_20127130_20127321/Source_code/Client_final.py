from tkinter.ttk import Combobox
from tkinter import messagebox
from tkinter import *
import socket

PORT = 8080
FORMAT = 'utf-8'


reset=0
connect =0

def delete_label():

    empty.destroy()

def recv_data_from_server():
    global empty
    if x_1.get() =="":
        messagebox.showinfo("Error","Bạn chưa nhập tên tiền tệ, vd: EUR")
    else:
        client.send(bytes("tra cuu",FORMAT))
        client.send(bytes(x_1.get(),FORMAT))
        data_money = client.recv(1024).decode(FORMAT)
        if data_money =="sai ten tien":
            messagebox.showinfo("Error","Bạn đã nhập sai tên tiền tệ\n Lưu ý phải in hoa tất cả chữ cái")
        elif data_money == "nhap khoang trang":
            messagebox.showinfo("Error","vui lòng nhập tên tiền tệ , vd: EUR")
        else:

            empty = Label(window)
            empty.pack()
            empty.config(text = data_money)


def print_table():

    if reset==0:
        messagebox.showinfo("Error","Bạn cần phải đăng nhập để tiến hành tra cứu")
    else:
        global item
        global x_1
        global window
        window = Tk()
        window.geometry('400x400')
        window.title("Bảng Tra Cứu")
        item = StringVar()
        l2 = Label(window, text="Các đồng ngoại tệ có thể tra cứu").pack()
        combobox = Combobox(window, textvariable=item,
                        values=["AUD", "CAD", "CHF", "DKK", "EUR", "GBP", "HKD", "JPY", "KRW", "LAK", "NOK", "NZD",
                                "SEK", "SGD", "THB", "USD"])
        combobox.pack()
        x_2 = Label(window, text= "vui lòng nhập tên tiền tệ cần tra cứu").pack()
        x_1 = Entry(window)
        x_1.pack()
        Button(window, text="Tra Cứu", command=recv_data_from_server).pack()
        Button(window,text = "Xóa mục vừa đã tra cứu",command= delete_label).pack()
        window.mainloop()


def dangky():
    if connect == 1:
        dangky = Tk()
        global tk_var
        global mk_var
        dangky.geometry('300x300')
        dangky_tk = Label(dangky, text="tài khoản")
        dangky_mk = Label(dangky, text='mật khẩu')
        tk_var = Entry(dangky, text='nhập tên nguòi dùng')
        mk_var = Entry(dangky, text='Nhập mật khẩu đăng kí')
        dangky_tk.grid(column=0, row=0)
        dangky_mk.grid(column=0, row=1)
        tk_var.grid(column=1, row=0)
        mk_var.grid(column=1, row=1)
        dangki_Button = Button(dangky, text='Đăng kí', command=dangky_nguoidung).grid(column=1, row=2)
    else:
        messagebox.showinfo("Error", "Vui lòng kết nối với server")
def dangky_nguoidung():

        client.send(bytes("dang ky", FORMAT))
        client.send(bytes(tk_var.get(), FORMAT))
        client.send(bytes(mk_var.get(), FORMAT))
        #print("gui dang ky")
        #print("tk: "+ tk_var.get())
       # print("mk: "+ mk_var.get())
        data_thong_bao_dangky =client.recv(1024).decode(FORMAT)
        if data_thong_bao_dangky == "da ton tai tai khoan":
            messagebox.showinfo("Thông Báo", "Tài khoản đã tồn tại \n Vui lòng đặt tên tài khoản khác và thử lại")
        if data_thong_bao_dangky == "dang ky thanh cong":
            messagebox.showinfo("Thông Báo", "Đã đăng ký tài khoản thành công")

def dangnhap_nguoidung():
    if connect==1:
        if taikhoanEntry.get()=="" and matkhauEntry.get()!="":
             messagebox.showinfo("Error","Vui lòng nhập tài khoản")
        elif matkhauEntry.get()=="" and taikhoanEntry.get()!="" :
            messagebox.showinfo("Error","Vui lòng nhập mật khẩu")
        elif taikhoanEntry.get()=="" and  matkhauEntry.get()=="":
            messagebox.showinfo("Error", "Vui lòng nhập tài khoản và mật khẩu")
        else:
            client.send(bytes("dang nhap", FORMAT))
            client.send(bytes(taikhoanEntry.get(), FORMAT))
            #print("gui dang nhap")
            #print("tk: " + taikhoanEntry.get())
            client.send(bytes(matkhauEntry.get(), FORMAT))



            #print("mk: " + matkhauEntry.get())
            data_thong_bao_dangnhap = client.recv(1024).decode(FORMAT)
            if data_thong_bao_dangnhap == "thanh cong":
                choice_box = messagebox.askyesno("Thông Báo", "Đã đăng nhập thành công \n Bạn có muốn đi đến mục tra cứu tiền tệ hay không?")
                global reset
                reset =1
                if choice_box ==1:
                    print_table()
            if data_thong_bao_dangnhap =="khong thanh cong":
                messagebox.showinfo("Error","Bạn đã nhập sai tài khoản hoặc mật khẩu")
    else:
        messagebox.showinfo("Error","vui lòng kết nối với server")
def Quit():
    click = messagebox.askyesno("Thông Báo","Bạn muốn thoát?")
    if click ==1:
        root.destroy()
        exit()

def main_tkinter():
    global taikhoanEntry
    global matkhauEntry
    global IP_Entry
    global root
    root = Tk()
    root.title("WELCOME CLIENT ")
    my_canvas = Canvas(root, width=800, height=500)
    my_canvas.pack(fill="both", expand=True)
    back_ground = PhotoImage(file=("money_resizee.png"))
    my_canvas.create_image(0,0, image=back_ground, anchor="nw")
    my_canvas.create_text(400, 250, text="WELCOME", font=("Helvetica", 40) ,fill="white")
    login_Button = Button(root, text="Đăng nhập", command=dangnhap_nguoidung)
    taikhoanLabel = Label(root, text="Nhập Tài khoản")
    matkhauLabel = Label(root, text="Nhập mật khẩu")
    taikhoanEntry = Entry(root, width=20)
    matkhauEntry = Entry(root, width=20, show='*')
    login_Button = Button(root, text="Đăng nhập", command=dangnhap_nguoidung)
    signup_Button = Button(root, text="Đăng ký", command=dangky)
    tracuu_Button = Button(root, text="Tra Cứu", command=print_table)
    quit_Button = Button(root,text="Quit",command=Quit)
    IP_Entry = Entry(root,text="Nhập IP", width=20)
    IP_Label =Label(root,text="Nhập IP")
    IP_Button = Button(root,text="Kết nối",command=connect)
    button2_window = my_canvas.create_window(325, 300, window=taikhoanLabel)
    button3_window = my_canvas.create_window(450,300, window=taikhoanEntry)
    button4_window = my_canvas.create_window(325, 325, window=matkhauLabel)
    button5_window = my_canvas.create_window(450, 325, window=matkhauEntry)
    button6_window = my_canvas.create_window(325, 350, window=login_Button)
    button7_window = my_canvas.create_window(325, 375, window=signup_Button)
    button8_window = my_canvas.create_window(325, 400, window=tracuu_Button)
    button9_window = my_canvas.create_window(325, 425, window=quit_Button)
    button10_window =my_canvas.create_window(450, 280, window=IP_Entry)
    button11_window = my_canvas.create_window(325, 280, window=IP_Label)
    button12_window = my_canvas.create_window(550, 280, window=IP_Button)
    root.mainloop()

def connect():
    global connect
    global client
    print("IP :" + IP_Entry.get())
    if IP_Entry.get()!="":
        HOST = IP_Entry.get()
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        ADDR = (HOST, PORT)
        client.connect(ADDR)
        print("connected")
        connect=1
    else:
        messagebox.showinfo("Error","vui lòng nhập địa chỉ IP")


def Start():
    main = Tk()
    global IP
    IP = StringVar()
    main.geometry('200x200')
    main.title ("WELCOME")
    IP = Entry(main,text = "IP")
    IP.grid(column=0,row=0)
    ip_button = Button(main,text="nhập IP",command=connect)
    ip_button.grid(column=1,row=0)
    main.mainloop()



main_tkinter()