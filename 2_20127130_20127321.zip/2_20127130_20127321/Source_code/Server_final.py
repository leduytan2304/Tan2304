from tkinter import *
from tkinter import messagebox
import socket
import threading
from _thread import *
import requests
import time

PORT = 8080
FORMAT = 'utf-8'
HOST = socket.gethostbyname(socket.gethostname())
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
ADDR=( HOST , PORT)
server.bind( ADDR )
server.listen()
print("IP SERVER:  " + HOST)
url = 'https://vapi.vnappmob.com'
def key_api():
    try:
        link = url + "/api/request_api_key?scope=exchange_rate"
        response = requests.get(link)
        return response.json()['results']
    except Exception as err:
        print(err)
def get_exchange_rate(url_1, api_key):
    try:
        link = url + url_1 + "?api_key=" + api_key
        response = requests.get(link)
        return response.json()["results"]
    except Exception as err:
        print(err)
total_data = get_exchange_rate("/api/v2/exchange_rate/ctg", key_api())
def update_data():
    with open("data_web.txt","w") as f:
        for item in range(len(total_data)):
            buy_cash = total_data[item]['buy_cash']
            buy_transfer = total_data[item]['buy_transfer']
            currency = total_data[item]['currency']
            sell=total_data[item]['sell']
            f.write("Currency name  " + str(currency))
            f.write("  Buy  " + str(buy_cash))
            f.write("  Transfer  " + str(buy_transfer))
            f.write("  Sell  " +str(sell)+ "\n")
            #print(buy_cash,buy_transfer,currency,sell)
    f.close()
def countdown():
    time_sec=1800
    while time_sec:
        mins, secs = divmod(time_sec, 60)
        timeformat = '{:02d}:{:02d}'.format(mins, secs)
        print(timeformat, end='\r')
        time.sleep(1)
        time_sec -= 1
    total_data = get_exchange_rate("/api/v2/exchange_rate/ctg", key_api())
    update_data()
    print("Data Updated!!")
update_data()





def currency_choice():

    print("money_choice: " + str(choice))
    with open("data_web.txt","r") as f:

        if choice == "AUD":
            lines = f.readlines()[0]
            client.send(bytes(lines,FORMAT))
            print(lines)
        elif choice == "CAD":
            lines = f.readlines()[1]
            client.send(bytes(str(lines), FORMAT))
        elif choice == "CHF":
            lines = f.readlines()[2]
            client.send(bytes(str(lines),FORMAT))
        elif choice == "CNY":
            lines = f.readlines()[3]
            client.send(bytes(str(lines),FORMAT))
        elif choice == "DKK":
            lines = f.readlines()[4]
            client.send(bytes(str(lines),FORMAT))
        elif choice == "EUR":
            lines = f.readlines()[5]
            client.send(bytes(str(lines),FORMAT))
        elif choice == "GBP":
            lines = f.readlines()[6]
            client.send(bytes(str(lines),FORMAT))
        elif choice == "HKD":
            lines = f.readlines()[7]
            client.send(bytes(str(lines),FORMAT))
        elif choice == "JPY":
            lines = f.readlines()[8]
            client.send(bytes(str(lines),FORMAT))
        elif choice== "KRW":
            lines = f.readlines()[9]
            client.send(bytes(str(lines),FORMAT))
        elif choice == "LAK":
            lines = f.readlines()[10]
            client.send(bytes(str(lines),FORMAT))
        elif choice == "NOK":
            lines = f.readlines()[11]
            client.send(bytes(str(lines),FORMAT))
        elif choice == "NZD":
            lines = f.readlines()[12]
            client.send(bytes(str(lines),FORMAT))
        elif choice == "SEK":
            lines = f.readlines()[13]
            client.send(bytes(str(lines),FORMAT))
        elif choice == "SGD":
            lines = f.readlines()[14]
            client.send(bytes(str(lines),FORMAT))
        elif choice == "THB":
            lines = f.readlines()[15]
            client.send(bytes(str(lines),FORMAT))
        elif choice == "USD":
            lines = f.readlines()[16]
            client.send(bytes(str(lines),FORMAT))
        else:
            client.send(bytes("sai ten tien",FORMAT))
            print("Tiền tệ không hợp lệ")

    f.close()



with open('taikhoan.txt') as ftk:
    sodongtk = sum(1 for line in ftk)
ftk.close()

with open('matkhau.txt') as fmk:
    sodongmk = sum(1 for line in fmk)
fmk.close()




def kiemtradangnhap():
    with open('taikhoan.txt') as ftk:
        sodongtk = sum(1 for line in ftk)
    ftk.close()
    count = 0
    keyline = 0
    with open('taikhoan.txt', 'r') as f_doc_tk:
        datalist = f_doc_tk.readlines()
        for i in range(sodongtk):
            if (tk_tu_client + '\n') == datalist[i]:
                count += 1
                keyline = i
    f_doc_tk.close()

    with open('matkhau.txt', 'r') as f_doc_mk:
        datalist = f_doc_mk.readlines()
        if (mk_tu_client + '\n') == datalist[keyline]:
            count += 1
    f_doc_mk.close()

    if count == 2:
        print('Đăng nhập thành công')
        client.send(bytes("thanh cong",FORMAT))
    else:
        client.send(bytes("khong thanh cong", FORMAT))
        print('Sai tài khoản hoặc mật khẩu')








def kiemtradangky():

    dacotaikhoan = 0
    with open('taikhoan.txt', 'r') as f_doc_tk:
        datalist = f_doc_tk.readlines()
        for i in range(sodongtk):
            if (tk_tu_client + '\n') == datalist[i]:
                dacotaikhoan = dacotaikhoan + 1
                print('Tài khoản đã tồn tại')
                client.send(bytes("da ton tai tai khoan",FORMAT))

                # gửi về client tài khoản đã tồn tại vui lòng chọn tên tài khoản khác----------------------------------------

    f_doc_tk.close()
    if dacotaikhoan == 0:
        f_ghi_tk = open('taikhoan.txt', 'a')
        f_ghi_tk.write(tk_tu_client)
        f_ghi_tk.write('\n')
        f_ghi_tk.close()
        f_ghi_mk = open('matkhau.txt', 'a')
        f_ghi_mk.write(mk_tu_client)
        f_ghi_mk.write('\n')
        f_ghi_mk.close()
        print('Đăng ký tài khoản thành công')
        client.send(bytes("dang ky thanh cong", FORMAT))
def Handle_Clients(client,addr):
   while True:

        yeu_cau = client.recv(1024).decode(FORMAT)

        global tk_tu_client
        global mk_tu_client

        if yeu_cau == "dang ky":
            tk_tu_client = client.recv(5).decode(FORMAT)
            #print("tk: "+tk_tu_client)

            mk_tu_client = client.recv(40).decode(FORMAT)
            #print("mk: "+mk_tu_client)
            kiemtradangky()
        if yeu_cau == "dang nhap":

            tk_tu_client = client.recv(5).decode(FORMAT)
            #print("tk: "+(tk_tu_client))
            mk_tu_client = client.recv(40).decode(FORMAT)

            #print("mk: "+ mk_tu_client)
            kiemtradangnhap()
        if yeu_cau =="Quit":
            messagebox.showinfo("Thông Báo","Client đã ngắt kết nối")
            exit()
        if yeu_cau =="tra cuu":
            global choice
            choice = client.recv(15).decode(FORMAT)
            currency_choice()
        server.setblocking(1)
def quit():

    exit()


def Server():

    global client
    while True:

        print("Waiting for the incoming connections")
        client, addr = server.accept()
        print("connected")
        threading._start_new_thread(Handle_Clients,(client,addr))
        print("Waiting for next client")
def main_tkinter():

        root = Tk()
        root.title("WELCOME TO SERVER")
        root.geometry('500x500')
        root.title(HOST)
        bg = PhotoImage(file=("zzz.png"))
        my_canvas = Canvas(root, width=800, height=500)
        my_canvas.create_image(0, 0, image=bg, anchor="nw")
        my_canvas.pack(fill="both", expand=True)
        x=Button(root,text="Mở server",command=Server)
        button2_window = my_canvas.create_window(250, 250, window=x)

        root.mainloop()

x = threading.Thread(target=countdown)
x.start()


y = threading.Thread(target=main_tkinter)
y.start()